package com.jyu.blog.service;

import com.jyu.blog.dataobject.FirstCategory;
import io.swagger.models.auth.In;

public interface FirstCategoryService {

    /**
     * 新增或修改类目
     *
     * @param firstCategory
     * @return
     */
    FirstCategory save(FirstCategory firstCategory);

    /**
     * 删除类目
     * @param categoryId
     */
    void delete(Integer categoryId);
}
