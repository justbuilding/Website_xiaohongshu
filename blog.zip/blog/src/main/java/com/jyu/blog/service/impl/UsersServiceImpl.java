package com.jyu.blog.service.impl;

import com.jyu.blog.dataobject.Users;
import com.jyu.blog.repository.UsersRepository;
import com.jyu.blog.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServiceImpl implements UsersService {

    @Autowired
    private UsersRepository usersRepository;

    /**
     * 查询用户信息
     * @param usersName
     * @return
     */
    @Override
    public Users findByName(String usersName) {
        return usersRepository.findByUsersName(usersName);
    }

    /**
     * 修改用户信息
     * @param users
     * @return
     */
    @Override
    public Users save(Users users) {
        return usersRepository.save(users);
    }

    /**
     * 根据用户手机号查询
     * @param usersPhone
     * @return
     */
    @Override
    public Users login(String usersPhone) {

        return usersRepository.findAllByUsersPhone(usersPhone);
    }

}
