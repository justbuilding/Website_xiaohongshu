package com.jyu.blog.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * 用户类
 */

@Data
@Entity
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "用户id")
    private Integer usersId;

    @ApiModelProperty(value = "用户名")
    private String usersName;

    @ApiModelProperty(value = "用户手机号")
    private String usersPhone;

    @ApiModelProperty(value = "用户密码")
    private String usersPassword;

    @ApiModelProperty(value = "用户头像")
    private String usersIcon;

    @ApiModelProperty(value = "个性签名")
    private String usersSignature;
}
