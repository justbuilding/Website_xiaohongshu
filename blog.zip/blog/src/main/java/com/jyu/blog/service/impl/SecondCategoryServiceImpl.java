package com.jyu.blog.service.impl;

import com.jyu.blog.dataobject.SecondCategory;
import com.jyu.blog.repository.SecondCategoryRepository;
import com.jyu.blog.service.SecondCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SecondCategoryServiceImpl implements SecondCategoryService {

    @Autowired
    private SecondCategoryRepository secondCategoryRepository;


    /**
     * 默认情况下根据一级类目查询二级类目信息
     * @param categoryId
     * @return
     */
    @Override
    public List<SecondCategory> findByCategoryId(Integer categoryId) {
        return secondCategoryRepository.findByCategoryId(categoryId);
    }

    /**
     * 根据博主查询发布的二级类目信息
     * @param blogId
     * @return
     */
    @Override
    public List<SecondCategory> findByBlogId(Integer blogId) {
        return secondCategoryRepository.findByBlogId(blogId);
    }

    /**
     * 保存二级类目数据
     * @param secondCategory
     * @return
     */
    @Override
    public SecondCategory save(SecondCategory secondCategory) {
        return secondCategoryRepository.save(secondCategory);
    }

}
