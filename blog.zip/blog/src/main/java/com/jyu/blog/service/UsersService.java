package com.jyu.blog.service;

import com.jyu.blog.dataobject.Users;

/**
 * 用户service层接口
 */
public interface UsersService {

    /**
     * 根据用户名查询用户信息
     * @param usersName
     * @return
     */
    Users findByName(String usersName);


    /**
     * 添加用户或者修改用户信息
     * @param users
     * @return
     */
    Users save(Users users);

    /**
     * 根据用户手机号登录
     * @param usersPhone
     * @return
     */
    Users login(String usersPhone);
}
