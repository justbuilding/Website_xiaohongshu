package com.jyu.blog.repository;

import com.jyu.blog.dataobject.Blog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BlogRepository extends JpaRepository<Blog, Integer> {

    /**
     * 根据用户的id查询自己发表的博客
     * @param usersId
     * @return
     */
    List<Blog> findByUsersId(Integer usersId);

    /**
     * 根据博客的主题查询博客
     * @param blogTheme
     * @return
     */
    List<Blog> findByBlogTheme(String blogTheme);
}
