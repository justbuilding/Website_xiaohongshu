package com.jyu.blog.repository;

import com.jyu.blog.dataobject.SecondCategory;
import io.swagger.models.auth.In;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SecondCategoryRepository extends JpaRepository<SecondCategory, Integer> {


    /**
     * 默认是根据一级类目查询小框框信息
     * @param categoryId
     * @return
     */
    List<SecondCategory> findByCategoryId(Integer categoryId);

    /**
     * 根据特定的用户查询
     * @param blogId
     * @return
     */
    List<SecondCategory> findByBlogId(Integer blogId);

}
