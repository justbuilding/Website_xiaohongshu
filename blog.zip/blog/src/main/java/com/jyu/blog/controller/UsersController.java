package com.jyu.blog.controller;

import com.jyu.blog.dataobject.Users;
import com.jyu.blog.service.UsersService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/User")
@Api(value = "用户controller", tags = {"用户"})
@Controller
public class UsersController {

    @Autowired
    private UsersService usersService;

    /**
     * 请求登录页面
     * @return
     */
    @RequestMapping("/login")
    public String login() {
        return "login";
    }

    /**
     * 根据用户手机号和密码进行登录
     * @param usersPhone
     * @param password
     * @return
     */
    @RequestMapping("/user")
    public String findByUsersPhone(@RequestParam(value = "usersPhone") String usersPhone,
                                   @RequestParam(value = "password") String password) {

        if (usersPhone != null) {
            Users result = usersService.login(usersPhone);
            if (password.equals(result.getUsersPassword())) {
                return "success";
            }
        } else {
            return "error";
        }
        return "error";
    }


    @RequestMapping("/users")
    public String findByName(@RequestParam(value = "usersName") String usersName,
                             @RequestParam(value = "password") String password) {

        Users users = usersService.findByName(usersName);
        System.out.println(users);
        System.out.println("用户名" + usersName);
        System.out.println("密码" + password);
        return "success";
    }

}
