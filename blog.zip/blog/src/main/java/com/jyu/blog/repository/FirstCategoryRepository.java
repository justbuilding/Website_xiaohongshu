package com.jyu.blog.repository;

import com.jyu.blog.dataobject.FirstCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FirstCategoryRepository extends JpaRepository<FirstCategory, Integer> {

}
