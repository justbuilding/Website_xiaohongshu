package com.jyu.blog.service;

import com.jyu.blog.dataobject.Blog;

import java.util.List;

/**
 * 博客service层接口
 */

public interface BlogService {

    /**
     * 用于添加或者是修改
     *
     * @param blog
     * @return
     */
    Blog save(Blog blog);

    /**
     * 根据用户id查询所有博客
     *
     * @param usersId
     * @return
     */
    List<Blog> findByUsersId(Integer usersId);

    /**
     * 根据博客主题查询博客
     * @param blogTheme
     * @return
     */
    List<Blog> findByBlogTheme(String blogTheme);

    /**
     * 删除博客
     * @param blogId
     */
    void deleteBlog(Integer blogId);
}
