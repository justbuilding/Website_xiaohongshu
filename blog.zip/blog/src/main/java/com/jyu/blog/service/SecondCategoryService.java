package com.jyu.blog.service;

import com.jyu.blog.dataobject.SecondCategory;
import io.swagger.models.auth.In;

import java.util.List;

public interface SecondCategoryService {

    /**
     * 默认情况下根据一级类目查询二级类目信息
     * @return
     */
    List<SecondCategory> findByCategoryId(Integer categoryId);

    /**
     * 根据博主查询发布的二级类目信息
     * @return
     */
    List<SecondCategory> findByBlogId(Integer blogId);

    /**
     * 保存二级类目数据
     * @return
     */
    SecondCategory save(SecondCategory secondCategory);


}
