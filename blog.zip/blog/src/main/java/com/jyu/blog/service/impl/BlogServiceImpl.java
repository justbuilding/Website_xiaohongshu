package com.jyu.blog.service.impl;

import com.jyu.blog.dataobject.Blog;
import com.jyu.blog.repository.BlogRepository;
import com.jyu.blog.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BlogServiceImpl implements BlogService {

    @Autowired
    private BlogRepository blogRepository;

    /**
     * 增加修改博客
     * @param blog
     * @return
     */
    @Override
    public Blog save(Blog blog) {
        return blogRepository.save(blog);
    }

    /**
     * 根据用户id查询用户博客
     * @param usersId
     * @return
     */
    @Override
    public List<Blog> findByUsersId(Integer usersId) {
        return blogRepository.findByUsersId(usersId);
    }

    /**
     * 根据主题查询博客
     * @param blogTheme
     * @return
     */
    @Override
    public List<Blog> findByBlogTheme(String blogTheme) {
        return blogRepository.findByBlogTheme(blogTheme);
    }

    /**
     * 删除博客
     * @param blogId
     */
    @Override
    public void deleteBlog(Integer blogId) {
        blogRepository.deleteById(blogId);
    }
}
