package com.jyu.blog.service.impl;

import com.jyu.blog.dataobject.FirstCategory;
import com.jyu.blog.repository.FirstCategoryRepository;
import com.jyu.blog.service.FirstCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FirstCategoryServiceImpl implements FirstCategoryService {

    @Autowired
    private FirstCategoryRepository firstCategoryRepository;

    /**
     * 修改类目方法
     * @param firstCategory
     * @return
     */
    @Override
    public FirstCategory save(FirstCategory firstCategory) {
        return firstCategoryRepository.save(firstCategory);
    }

    /**
     * 删除类目方法
     * @param categoryId
     */
    @Override
    public void delete(Integer categoryId) {
        firstCategoryRepository.deleteById(categoryId);
    }
}
