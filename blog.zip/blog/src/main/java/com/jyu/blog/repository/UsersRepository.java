package com.jyu.blog.repository;

import com.jyu.blog.dataobject.Users;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsersRepository extends JpaRepository<Users,Integer> {

    /**
     * 根据用户名查询用户信息
     * @param usersName
     * @return
     */
    Users findByUsersName(String usersName);


    /**
     * 根据用户手机查询用户
     * @param usersPhone
     * @return
     */
    Users findAllByUsersPhone(String usersPhone);
}
