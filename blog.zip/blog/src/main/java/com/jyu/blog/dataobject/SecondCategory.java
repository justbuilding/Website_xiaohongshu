package com.jyu.blog.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@Entity
public class SecondCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "二级类目id")
    private Integer secondCategoryId;

    @ApiModelProperty(value = "二级类目名")
    private String secondCategoryName;

    @ApiModelProperty(value = "二级类目图片")
    private String secondCategoryUrl;

    @ApiModelProperty(value = "博客id")
    private Integer blogId;

    @ApiModelProperty(value = "一级类目id")
    private Integer categoryId;
}
