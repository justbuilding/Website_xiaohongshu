package com.jyu.blog.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@Entity
public class Blog {

    @Id
    @ApiModelProperty(value = "博客id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer blogId;

    @ApiModelProperty(value = "博客主题")
    private String blogTheme;

    @ApiModelProperty(value = "博客内容")
    private String blogContext;

    @ApiModelProperty(value = "博客状态")
    private Integer blogStatus;

    @ApiModelProperty(value = "博客点赞量")
    private String blogPraise;

    @ApiModelProperty(value = "用户id")
    private Integer usersId;
}
