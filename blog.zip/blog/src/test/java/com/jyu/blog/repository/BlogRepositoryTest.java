package com.jyu.blog.repository;

import com.jyu.blog.dataobject.Blog;
import io.swagger.annotations.ApiModelProperty;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.List;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class BlogRepositoryTest {

    @Autowired
    private BlogRepository blogRepository;


    @Test
    public void save() {
        Blog blog = new Blog();
        blog.setBlogTheme("时尚");
        blog.setBlogContext("小红书教你如何穿搭！");
        blog.setBlogStatus(0);
        blog.setUsersId(1);
        blog.setBlogPraise("515");
        Blog result = blogRepository.save(blog);
        System.out.println(result);
        Assert.notNull(result);
    }

    @Test
    public void findByUsersId() {
        List<Blog> result = blogRepository.findByUsersId(1);
        System.out.println(result);
        org.junit.Assert.assertNotNull(result);
    }

    @Test
    public void findByBlogTheme() {
        List<Blog> result = blogRepository.findByBlogTheme("时尚");
        System.out.println(result);
        Assert.notNull(result);
    }

}