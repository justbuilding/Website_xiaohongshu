package com.jyu.blog.repository;

import com.jyu.blog.dataobject.FirstCategory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.Date;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class FirstCategoryRepositoryTest {

    @Autowired
    private FirstCategoryRepository firstCategoryRepository;

    @Test
    public void save() {
        FirstCategory firstCategory = new FirstCategory();
        firstCategory.setCategoryName("数码");
        firstCategory.setCategoryStatus(0);
        firstCategory.setCreateTime(new Date());
        firstCategory.setUpdateTime(new Date());
        FirstCategory result = firstCategoryRepository.save(firstCategory);
        Assert.notNull(result);
    }
}