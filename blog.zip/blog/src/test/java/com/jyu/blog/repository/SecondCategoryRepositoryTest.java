package com.jyu.blog.repository;

import com.jyu.blog.dataobject.SecondCategory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SecondCategoryRepositoryTest {

    @Autowired
    private SecondCategoryRepository secondCategoryRepository;

    @Test
    public void save() {
        SecondCategory secondCategory = new SecondCategory();
        secondCategory.setSecondCategoryName("手机");
        secondCategory.setSecondCategoryUrl("1.jpg");
        secondCategory.setBlogId(1);
        secondCategory.setCategoryId(1);
        SecondCategory result = secondCategoryRepository.save(secondCategory);
        System.out.println(result);
        Assert.notNull(result);
    }

    @Test
    public void findByCategoryId() {
        List<SecondCategory> result = secondCategoryRepository.findByCategoryId(1);
        System.out.println(result);
        Assert.notNull(result);

    }

    @Test
    public void findByBlogId() {
        List<SecondCategory> result = secondCategoryRepository.findByBlogId(1);
        System.out.println(result);
        Assert.notNull(result);
    }
}