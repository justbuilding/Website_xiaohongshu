package com.jyu.blog.repository;

import com.jyu.blog.dataobject.Users;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UsersRepositoryTest {

    @Autowired
    private UsersRepository usersRepository;

    @Test
    public void save() {
        Users users = new Users();
        users.setUsersName("李四");
        users.setUsersPhone("17875305703");
        users.setUsersPassword("123");
        users.setUsersIcon("1.jpg");
        Users u = usersRepository.save(users);
        System.out.println(u);
        Assert.notNull(u,"chenggong ");

    }

    @Test
    public void findAll() {
        List<Users> list = usersRepository.findAll();
        System.out.println(list);
        Assert.notNull(list);
    }

    @Test
    public void findOne() {
        Optional<Users> users = usersRepository.findById(1);
        System.out.println(users);
        Assert.notNull(users);
    }

    @Test
    public void findByUsersName() {
        String usersName = "张三";
        Users users = usersRepository.findByUsersName(usersName);
        System.out.println(users);
        Assert.notNull(users);
    }

    @Test
    public void findByUsersPhone() {
        Users result = usersRepository.findAllByUsersPhone("15724089330");
        System.out.println(result);
        Assert.notNull(result);
    }
}