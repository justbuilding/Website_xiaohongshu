/*
Navicat MySQL Data Transfer

Source Server         : 数据库项目
Source Server Version : 80011
Source Host           : localhost:3306
Source Database       : blog

Target Server Type    : MYSQL
Target Server Version : 80011
File Encoding         : 65001

Date: 2019-03-16 12:43:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for blog
-- ----------------------------
DROP TABLE IF EXISTS `blog`;
CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '博客id',
  `blog_theme` varchar(256) NOT NULL COMMENT '博客主题相当于类目名称',
  `blog_context` varchar(512) NOT NULL COMMENT '博客内容',
  `blog_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0发表状态,1表示已删除',
  `blog_praise` varchar(64) DEFAULT '0' COMMENT '点赞量',
  `users_id` int(11) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`blog_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of blog
-- ----------------------------

-- ----------------------------
-- Table structure for first_category
-- ----------------------------
DROP TABLE IF EXISTS `first_category`;
CREATE TABLE `first_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '类目id',
  `category_name` varchar(32) NOT NULL COMMENT '类目名称',
  `category_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '类目状态,0正在使用,1已经删除',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of first_category
-- ----------------------------

-- ----------------------------
-- Table structure for second_category
-- ----------------------------
DROP TABLE IF EXISTS `second_category`;
CREATE TABLE `second_category` (
  `second_category_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '二级类目id',
  `second_category_name` varchar(32) NOT NULL COMMENT '类目名称',
  `second_category_url` varchar(256) NOT NULL COMMENT '类目图片',
  `blog_id` int(11) DEFAULT NULL COMMENT '博客id',
  `category_id` int(11) DEFAULT NULL COMMENT '一级类目id',
  PRIMARY KEY (`second_category_id`),
  KEY `idx_category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of second_category
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `users_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `users_name` varchar(64) NOT NULL COMMENT '用户名',
  `users_phone` varchar(32) NOT NULL COMMENT '用户手机号',
  `users_password` varchar(32) NOT NULL COMMENT '用户密码',
  `users_icon` varchar(256) NOT NULL COMMENT '用户头像',
  `users_signature` varchar(256) DEFAULT NULL COMMENT '个性签名',
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
